package ar.edu.davinci.dvds20241cg9;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class dvds20241cg9ApplicationTests {

	@Test
	void contextLoads() {
	}

}
