package ar.edu.davinci.dvds20241cg9;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DvDs20241cG9Application {

	public static void main(String[] args) {
		SpringApplication.run(DvDs20241cG9Application.class, args);
	}

}
