package ar.edu.davinci.dvds20241cg9.controller.response;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class VentaEfectivoResponse extends VentaResponse {

}
