package ar.edu.davinci.dvds20241cg9;

public interface Constantes {
	public static final String FORMATO_FECHA = "dd-MM-yyyy";

}
